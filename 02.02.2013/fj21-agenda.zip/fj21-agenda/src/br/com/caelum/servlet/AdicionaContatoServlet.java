package br.com.caelum.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.agenda.dao.ContatoDAO;
import br.com.caelum.agenda.modelo.Contato;

public class AdicionaContatoServlet extends HttpServlet{
	
	protected void service(HttpServletRequest req, HttpServletResponse resp) 
	{
		String nome = req.getParameter("nome");
		String email = req.getParameter("email");
		String endereco = req.getParameter("endereco");
		String dataTexto = req.getParameter("dataNascimento");
		Date data = null;
		
		try {
			data = new SimpleDateFormat("dd/mm/yyyy").parse(dataTexto);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		Calendar dataNascimento = Calendar.getInstance();
		dataNascimento.setTime(data);
		
		Contato contato = new Contato();
		
		contato.setNome(nome);
		contato.setEmail(email);
		contato.setEndereco(endereco);
		contato.setDataNascimento(dataNascimento);
		
		ContatoDAO dao = new ContatoDAO();
		dao.adiciona(contato);
		
		//Redireciona para a página de confirmaçao
		RequestDispatcher rd = req.getRequestDispatcher("/contato-adicionado.jsp");
		try {
			rd.forward(req, resp);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
