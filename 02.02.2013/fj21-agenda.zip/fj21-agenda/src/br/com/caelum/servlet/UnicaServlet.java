package br.com.caelum.servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UnicaServlet extends HttpServlet {

	protected void service(HttpServletRequest requisicao, HttpServletResponse resposta)
	{
		String acao = requisicao.getParameter("logica");
		String nomeDaClasse = "br.com.caelum.agenda.mvc.logica" + acao;
		
	}
	
}
