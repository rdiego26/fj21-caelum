package br.com.caelum.mvc.logica;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.agenda.dao.ContatoDAO;
import br.com.caelum.agenda.modelo.Contato;

public class RemoveContatoLogic implements Logica {

	@Override
	public void executa(HttpServletRequest requisicao,
			HttpServletResponse resposta) throws Exception {	
		
		Contato contato = new Contato();
		long id = Long.parseLong(requisicao.getParameter("id"));
		
		contato.setId(id);		
		ContatoDAO dao = new ContatoDAO();
		dao.deleta(contato);
		
		RequestDispatcher rd = requisicao.getRequestDispatcher("lista-contatos-elegante.jsp");
		rd.forward(requisicao, resposta);
		
		System.out.println("Deletando contato ... " + contato.getNome());		

	}

}
