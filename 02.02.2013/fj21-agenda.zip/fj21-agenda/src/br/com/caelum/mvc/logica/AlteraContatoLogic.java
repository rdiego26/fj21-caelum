package br.com.caelum.mvc.logica;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.agenda.dao.ContatoDAO;
import br.com.caelum.agenda.modelo.Contato;

public class AlteraContatoLogic implements Logica {

	@Override
	public void executa(HttpServletRequest requisicao,
			HttpServletResponse resposta) throws Exception {
		
		Contato contato = new Contato();
		
		long id = Long.parseLong(requisicao.getParameter("id"));
		
		contato.setId(id);
		contato.setNome(requisicao.getParameter("nome"));
		contato.setEndereco(requisicao.getParameter("endereco"));
		contato.setEmail(requisicao.getParameter("email"));
		
		//Converte data de String para Calendar
		String dataEmTexto = requisicao.getParameter("dataNascimento");
		Date date = new SimpleDateFormat("dd/MM/yyyy").parse(dataEmTexto);
		
		Calendar dataNascimento = Calendar.getInstance();
		dataNascimento.setTime(date);
		
		contato.setDataNascimento(dataNascimento);
		
		ContatoDAO dao = new ContatoDAO();
		dao.atualiza(contato);
		
		RequestDispatcher rd = requisicao.getRequestDispatcher("lista-contatos-elegante.jsp");
		rd.forward(requisicao, resposta);
		
		System.out.println("Alterando contato ... " + contato.getNome());
		

	}

}
